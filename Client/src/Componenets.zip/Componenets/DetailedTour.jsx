import React, { Component } from 'react';

class DetailedTour extends Component {
    render() {
        return (
            <div>
                <CardGroup>

                    <PackagesCard id={101} />
                    <p></p>
                    <PackagesCard id={102} />
                    <p></p>
                    <PackagesCard id={103} />

                </CardGroup>
                <CardGroup>

                    <PackagesCard id={105} />
                    <p></p>
                    <PackagesCard id={107} />
                    <p></p>
                    <PackagesCard id={108} />

                </CardGroup>
                <CardGroup>

                    <PackagesCard id={110} />
                    <p></p>
                    <PackagesCard id={111} />
                    <p></p>
                    <PackagesCard id={112} />

                </CardGroup>
            </div>
        );
    }
}

export default DetailedTour;